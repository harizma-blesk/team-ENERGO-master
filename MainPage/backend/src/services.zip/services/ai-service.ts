import { Difficulty, QuestionType } from '@prisma/client';
import { env } from '../config/env.js';
import { sha256 } from '../utils/hash.js';

/* ================= TYPES ================= */

export type GeneratorInput = {
  subjectName: string;
  subjectDescription?: string | null;
  syllabus?: unknown;
  difficulty: Difficulty;
  topicCodes: string[];
  questionTypes: QuestionType[];
  questionCount: number;
  language: string;
};

export type GeneratedQuestion = {
  type: QuestionType;
  stem: string;
  topicCode: string;
  difficulty: Difficulty;
  options?: { code: string; text: string; isCorrect?: boolean }[];
  correctOptionCodes?: string[];
  expectedAnswer?: string;
  keywords?: string[];
  rubric?: { criterion: string; maxPoints: number }[];
  fingerprint: string;
};

type GeminiRaw = {
  type: unknown;
  stem: unknown;
  topicCode: unknown;
  options?: { code: string; text: string; isCorrect?: boolean }[];
  correctOptionCodes?: string[];
};

/* ================= HELPERS ================= */

const normalize = (s: string) =>
    s.trim().replace(/\s+/g, ' ');

const toLabel = (t: string) =>
    normalize(t)
        .replace(/[_-]+/g, ' ')
        .replace(/\b\w/g, c => c.toUpperCase());

const isPlaceholder = (t: string) => {
  const v = t.toLowerCase().trim();
  return ['core', 'general', 'topic', 'default'].includes(v);
};

const uniq = (arr: string[]) => {
  const set = new Set<string>();
  const res: string[] = [];
  for (const a of arr) {
    const n = normalize(a);
    if (!set.has(n.toLowerCase())) {
      set.add(n.toLowerCase());
      res.push(n);
    }
  }
  return res;
};

/* ================= TOPICS ================= */

const resolveTopics = (input: GeneratorInput) => {
  const explicit = uniq(input.topicCodes).filter(t => !isPlaceholder(t));
  if (explicit.length) return explicit;

  const fallback = uniq([input.subjectName]);
  return fallback.length ? fallback : ['Тема'];
};

/* ================= TYPES ================= */

const normalizeType = (t: any): QuestionType | null => {
  if (typeof t !== 'string') return null;
  const v = t.toUpperCase();

  if (v.includes('SINGLE')) return QuestionType.SINGLE_CHOICE;
  if (v.includes('MULTI')) return QuestionType.MULTI_CHOICE;
  if (v.includes('OPEN')) return QuestionType.OPEN_SHORT;

  return null;
};

/* ================= OPTIONS ================= */

const buildOptions = (topic: string, idx: number) => {
  const label = toLabel(topic);

  const correct = [
    `Понимание темы «${label}»`,
    `Практическое применение «${label}»`,
    `Анализ принципов «${label}»`,
    `Работа с концепцией «${label}»`,
  ];

  const wrong = [
    `Игнорирование правил «${label}»`,
    `Случайное использование «${label}»`,
    `Отключение проверки «${label}»`,
    `Работа без контроля «${label}»`,
  ];

  const pick = (arr: string[], i: number) => arr[(idx + i) % arr.length];

  return [
    { code: 'A', text: pick(correct, 0), isCorrect: true },
    { code: 'B', text: pick(correct, 1), isCorrect: true },
    { code: 'C', text: pick(wrong, 0), isCorrect: false },
    { code: 'D', text: pick(wrong, 1), isCorrect: false },
  ];
};

/* ================= GEMINI ================= */

const parseJsonSafe = (text: string) => {
  try {
    const start = text.indexOf('{');
    const end = text.lastIndexOf('}');
    if (start === -1 || end === -1) return null;

    return JSON.parse(text.slice(start, end + 1));
  } catch {
    return null;
  }
};

const callGemini = async (input: GeneratorInput): Promise<GeneratedQuestion[] | null> => {
  if (!env.GEMINI_API_KEY) return null;

  const url = `https://generativelanguage.googleapis.com/v1/models/${env.GEMINI_MODEL}:generateContent?key=${env.GEMINI_API_KEY}`;

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: `
Return ONLY JSON:
{
 "questions":[
  {
   "type":"SINGLE_CHOICE",
   "stem":"...",
   "topicCode":"...",
   "options":[
     {"code":"A","text":"..."},
     {"code":"B","text":"..."},
     {"code":"C","text":"..."},
     {"code":"D","text":"..."}
   ],
   "correctOptionCodes":["A"]
  }
 ]
}

Subject: ${input.subjectName}
Difficulty: ${input.difficulty}
Count: ${input.questionCount}
`
              }
            ]
          }
        ]
      })
    });

    const data = await res.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? '';

    const parsed = parseJsonSafe(text);
    if (!parsed?.questions) return null;

    const topics = resolveTopics(input);

    return parsed.questions.map((q: any, i: number) => ({
      type: normalizeType(q.type) ?? QuestionType.SINGLE_CHOICE,
      stem: q.stem ?? '',
      topicCode: q.topicCode ?? topics[i % topics.length],
      difficulty: input.difficulty,
      options: q.options,
      correctOptionCodes: q.correctOptionCodes,
      fingerprint: sha256(`${q.topicCode}:${i}`)
    }));
  } catch {
    return null;
  }
};

/* ================= FALLBACK ================= */

const fallbackQuestion = (
    topic: string,
    type: QuestionType,
    difficulty: Difficulty,
    idx: number
): GeneratedQuestion => {
  const label = toLabel(topic);

  const stem =
      type === QuestionType.OPEN_SHORT
          ? `Объясните тему «${label}»`
          : `Выберите правильный ответ по теме «${label}»`;

  const options =
      type === QuestionType.OPEN_SHORT ? undefined : buildOptions(topic, idx);

  return {
    type,
    stem,
    topicCode: topic,
    difficulty,
    options,
    correctOptionCodes: options?.filter(o => o.isCorrect).map(o => o.code),
    fingerprint: sha256(`${topic}:${stem}`)
  };
};

const fallbackGenerate = (input: GeneratorInput) => {
  const topics = resolveTopics(input);
  const types = input.questionTypes.length
      ? input.questionTypes
      : [QuestionType.SINGLE_CHOICE];

  return Array.from({ length: input.questionCount }).map((_, i) =>
      fallbackQuestion(
          topics[i % topics.length],
          types[i % types.length],
          input.difficulty,
          i
      )
  );
};

/* ================= MAIN ================= */

export const generateQuestions = async (input: GeneratorInput) => {
  const ai = await callGemini(input);

  if (ai && ai.length > 0) {
    return ai.slice(0, input.questionCount);
  }

  return fallbackGenerate(input);
};